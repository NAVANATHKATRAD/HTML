
/**
 * this function will give some output
 * @param {*} param 
 */
function show( param){
    console.log("sjcbsbkscbjas");
}